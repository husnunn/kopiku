export default {
  name: 'radio'
};